import os
import time

print("Hey there! Welcome to Carbo OS")
print("Carbo OS is secure open source python operating system")
print("designed to make computing fun and easier!")
print("") # Space.

print("First of all username and account! What should you know about them?")
print("First of all never ever share you password!")
print("And second off you can reset your password even your username.")
print("Via the BioS system or even safemode.")
print("") # Space.
print("Press [Any Key] to continue")
input()
os.system('cls')
print("Theres a lot you can do in Carbo OS.")
print("Wanna paint? You can do that!")
print("Wanna play ticktacktoe or some other game?")
print("You can do that!")
print("Want to manage all your files easily?")
print("You can also do that!")
print("") # Space.
print("Every day Carbo OS is being worked on.")
print("And often it gets security updates and software updates.")
print("Press [Any Key] to continue")
input()
os.system('cls')
print("Oh speaking of which!")
print("You should learn how to update your system.")
print("Keeping Carbo OS updated is very important to protecting your")
print("precious data and keeping up to date with the latest tech!")
print("") # Space.
print("Anywho thats it!")
print("If you want to update make sure to go to ")
print("the github page and downoad the latest one.")
print(":)")
print("") # Space.

print("Press [Any Key] to back to home.")
input()
exit()