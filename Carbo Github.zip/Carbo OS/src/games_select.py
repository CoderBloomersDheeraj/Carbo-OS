import os
import time

os.system('cls')

print("""
[1] Houge
[2] Minecraft
[3] Snake Game.
""")


while True:
    game_select = input(str("[?]: "))

    if game_select == '1':
        os.system('cls')
        os.startfile("Houge.py")
        break

    elif game_select == '2':
        os.system('cls')
        os.startfile("main.py")
        os.startfile("minecraft.py")
        break

    elif game_select == '3':
        os.startfile("main.py")
        os.startfile("snake.py")
        exit()

    else:
        print("Invaild option!")