

import time
import os
import sys

# Always execute KernelOS.py to start the OS.
# This contains our setup including setting up basic
# stuff like our username and password.

# If we are developing KernelOS then executing it manually by the
# cmd would be fine because when you get an error message it won't
# Close giving you no time to read the error message and which line
# python doesn't like.

os.system('cls') # Just in case theres any gunk before the OS starts.
print("Booting")
#animation = ["10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%"]
animation = ["[■□□□□□□□□□]","[■■□□□□□□□□]", "[■■■□□□□□□□]", "[■■■■□□□□□□]", "[■■■■■□□□□□]", "[■■■■■■□□□□]", "[■■■■■■■□□□]", "[■■■■■■■■□□]", "[■■■■■■■■■□]", "[■■■■■■■■■■]"]
for i in range(len(animation)):
    time.sleep(0.7)
    sys.stdout.write("\r" + animation[i % len(animation)])
    sys.stdout.flush()
print("\n")

os.system('cls')
print("""

░██╗░░░░░░░██╗███████╗██╗░░░░░░█████╗░░█████╗░███╗░░░███╗███████╗  ████████╗░█████╗░
░██║░░██╗░░██║██╔════╝██║░░░░░██╔══██╗██╔══██╗████╗░████║██╔════╝  ╚══██╔══╝██╔══██╗
░╚██╗████╗██╔╝█████╗░░██║░░░░░██║░░╚═╝██║░░██║██╔████╔██║█████╗░░  ░░░██║░░░██║░░██║
░░████╔═████║░██╔══╝░░██║░░░░░██║░░██╗██║░░██║██║╚██╔╝██║██╔══╝░░  ░░░██║░░░██║░░██║
░░╚██╔╝░╚██╔╝░███████╗███████╗╚█████╔╝╚█████╔╝██║░╚═╝░██║███████╗  ░░░██║░░░╚█████╔╝
░░░╚═╝░░░╚═╝░░╚══════╝╚══════╝░╚════╝░░╚════╝░╚═╝░░░░░╚═╝╚══════╝  ░░░╚═╝░░░░╚════╝░

░█████╗░░█████╗░██████╗░██████╗░░█████╗░  ░█████╗░░██████╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗  ██╔══██╗██╔════╝
██║░░╚═╝███████║██████╔╝██████╦╝██║░░██║  ██║░░██║╚█████╗░
██║░░██╗██╔══██║██╔══██╗██╔══██╗██║░░██║  ██║░░██║░╚═══██╗
╚█████╔╝██║░░██║██║░░██║██████╦╝╚█████╔╝  ╚█████╔╝██████╔╝
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░░╚════╝░  ░╚════╝░╚═════╝░
""")

time.sleep(5)
os.system('cls')
print("""
[1] Safe mode. (CarboOSPE)
[2] Boot normally.
""")

safeselect = input(str(">>>: "))

if safeselect == '1':
	print("Okay!")
	os.startfile("safemode.py")
	exit()

if safeselect == '2':
	print("Okay!")
	time.sleep(1)
	os.system('cls')
	# Move on and continue booting kernelOS.

# The proper way of booting kernelOS really is clicking on the py file.
# "KernelOS.py"

print("""

░█████╗░░█████╗░██████╗░██████╗░░█████╗░
██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗
██║░░╚═╝███████║██████╔╝██████╦╝██║░░██║
██║░░██╗██╔══██║██╔══██╗██╔══██╗██║░░██║
╚█████╔╝██║░░██║██║░░██║██████╦╝╚█████╔╝
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░░╚════╝░""")

print("""
[1] Continue with setup.
[2] I've already done the setup.
""")

setup = input("[?]: ")

if setup == '1':
	name = input(str("Please enter your User Name To Be Displayed: "))
	pas = input(str("Please enter your Password to login: "))

	lines = [name]
	# Using "pass" as the extension type to provide some level of encryption.
	# Since file explorer by default doesn't recongize pass as a text file.
	with open('user/username.pass', 'w') as f:
		f.writelines(lines)

	lines2 = [pas]
	with open('user/password.pass', 'w') as f:
		f.writelines(lines2)

	print("") # Space.

	print("FreeProjectOS setup complete!")
	print("Redirecting you to home...")
	input("Press Enter to Close Window: ")

if setup == '2':
	# Read our username and password
	# Like a goodboy.
	login_pass = open('user/password.pass')
	login_name = open('user/username.pass')
	l_p = login_pass.read()
	l_u = login_name.read()

	while True:
			login = input(str("Please Enter The Password To " + l_u + ": "))
			if login == l_p:
				os.startfile("main.py")
				break

			else:
				print("Invaild password, Try again!")

else:
	print("Invaild command!")
