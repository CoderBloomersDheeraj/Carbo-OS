import tkinter as tk
from tkinter import filedialog
import pygame

class MusicPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Carbo Music Player")
        self.root.geometry("400x300")
        self.root.configure(background="#3B5998")
        
        # Initialize pygame mixer
        pygame.mixer.init()
        
        # Create a label to display current song
        self.current_song = tk.StringVar()
        self.song_label = tk.Label(root, textvariable=self.current_song, bg="#3B5998", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
        self.song_label.pack(pady=10)
        
        # Create buttons
        self.play_button = tk.Button(root, text="▶ Play", command=self.play_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.play_button.pack(side=tk.LEFT, padx=10, pady=10)
        
        self.pause_button = tk.Button(root, text="|| Pause", command=self.pause_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.pause_button.pack(side=tk.LEFT, padx=10, pady=10)
        
        self.stop_button = tk.Button(root, text="■ Stop", command=self.stop_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.stop_button.pack(side=tk.LEFT, padx=10, pady=10)
        
        self.add_button = tk.Button(root, text="+ Add Music", command=self.add_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.add_button.pack(side=tk.LEFT, padx=10, pady=10)
        
        self.quit_button = tk.Button(root, text="✖ Quit", command=root.destroy, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.quit_button.pack(side=tk.LEFT, padx=10, pady=10)
        
        # Create a list to store music
        self.music_list = []
        
    def play_music(self):
        if pygame.mixer.music.get_busy() == 0 and self.music_list:
            pygame.mixer.music.load(self.music_list[0])
            pygame.mixer.music.play()
            self.current_song.set("Now playing: " + self.music_list[0])
            
    def pause_music(self):
        if pygame.mixer.music.get_busy() == 1:
            pygame.mixer.music.pause()
            self.current_song.set("Paused: " + self.music_list[0])
            
    def stop_music(self):
        if pygame.mixer.music.get_busy() == 1:
            pygame.mixer.music.stop()
            self.current_song.set("Stopped")
            
    def add_music(self):
        # Open a file dialog to select music files
        files = filedialog.askopenfilenames(filetypes=[("Music files", "*.mp3")])
        
        # Add selected files to the music list
        for file in files:
            self.music_list.append(file)
        

        # Add selected files to the music list
        for file in files:
            self.music_list.append(file)
        
        # Update the song label
        if self.music_list:
            self.current_song.set("Added " + str(len(files)) + " song(s).")
        
 
root = tk.Tk()
music_player = MusicPlayer(root)
root.mainloop()

2 / 2

import tkinter as tk
from tkinter import filedialog
import pygame

class MusicPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Music Player")
        self.root.geometry("400x300")
        self.root.configure(background="#3B5998")
        
        # Initialize pygame mixer
        pygame.mixer.init()
        
        # Create a label to display current song
        self.current_song = tk.StringVar()
        self.song_label = tk.Label(root, textvariable=self.current_song, bg="#3B5998", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
        self.song_label.pack(pady=10)
        
        # Create buttons
        self.play_button = tk.Button(root, text="▶ Play", command=self.play_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.play_button.pack(side=tk.LEFT, padx=10, pady=10, anchor="center", fill="both")
        
        self.pause_button = tk.Button(root, text="|| Pause", command=self.pause_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.pause_button.pack(side=tk.LEFT, padx=10, pady=10, anchor="center", fill="both")
        
        self.stop_button = tk.Button(root, text="■ Stop", command=self.stop_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.stop_button.pack(side=tk.LEFT, padx=10, pady=10, anchor="center", fill="both")
        
        self.add_button = tk.Button(root, text="+ Add Music", command=self.add_music, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.add_button.pack(side=tk.LEFT, padx=10, pady=10, anchor="center", fill="both")
        
        self.quit_button = tk.Button(root, text="✖ Quit", command=root.destroy, bg="#FFFFFF", fg="#3B5998", font=("Helvetica", 10, "bold"), padx=10, pady=6, bd=0)
        self.quit_button.pack(side=tk.LEFT, padx=10, pady=10, anchor="center", fill="both")
        
        # Create a list to store music
        self.music_list = []
        
    def play_music(self):
        if pygame.mixer.music.get_busy() == 0 and self.music_list:
            pygame.mixer.music.load(self.music_list[0])
            pygame.mixer.music.play()
            self.current_song.set("Now playing: " + self.music_list[0])
            
    def pause_music(self):
        if pygame.mixer.music.get_busy() == 1:
            pygame.mixer.music.pause()
            self.current_song.set("Paused: " + self.music_list[0])
            
    def stop_music(self):
        if pygame.mixer.music.get_busy() == 1:
            pygame.mixer.music.stop()
            self.current_song.set("Stopped")
            
    def add_music(self):
        # Open a file dialog to select music files
        files = filedialog.askopenfilenames(filetypes=[("Music files", "*.mp3")])
        
        #





